from pyspark.sql import DataFrame
from base_writer import BaseWriter


class DeltaWriter(BaseWriter):
    pass
