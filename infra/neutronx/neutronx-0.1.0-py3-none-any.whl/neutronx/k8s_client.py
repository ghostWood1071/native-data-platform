from __future__ import annotations

from typing import Any

from .config import K8sConfig
from .retry import safe_call
from .result import Result


def load_k8s(config: K8sConfig) -> Result[bool]:
    def _call() -> bool:
        from kubernetes import config as k8s_config

        if config.in_cluster:
            k8s_config.load_incluster_config()
        else:
            k8s_config.load_kube_config(config_file=config.kubeconfig_path)
        return True

    return safe_call(component="k8s", operation="load_config", fn=_call)


def custom_objects_api(config: K8sConfig) -> Result[Any]:
    load_result = load_k8s(config)
    if load_result.failed:
        return Result.fail(load_result.error)

    def _call() -> Any:
        from kubernetes import client

        return client.CustomObjectsApi()

    return safe_call(component="k8s", operation="custom_objects_api", fn=_call)


def get_custom_object(
    config: K8sConfig,
    *,
    group: str,
    version: str,
    plural: str,
    name: str,
    namespace: str | None = None,
) -> Result[dict[str, Any]]:
    api_result = custom_objects_api(config)
    if api_result.failed:
        return Result.fail(api_result.error)

    def _call() -> dict[str, Any]:
        return api_result.unwrap().get_namespaced_custom_object(
            group=group,
            version=version,
            namespace=namespace or config.namespace,
            plural=plural,
            name=name,
        )

    return safe_call(
        component="k8s",
        operation="get_custom_object",
        fn=_call,
        details={"group": group, "version": version, "plural": plural, "name": name},
    )


def create_custom_object(
    config: K8sConfig,
    *,
    group: str,
    version: str,
    plural: str,
    body: dict[str, Any],
    namespace: str | None = None,
) -> Result[dict[str, Any]]:
    api_result = custom_objects_api(config)
    if api_result.failed:
        return Result.fail(api_result.error)

    def _call() -> dict[str, Any]:
        return api_result.unwrap().create_namespaced_custom_object(
            group=group,
            version=version,
            namespace=namespace or config.namespace,
            plural=plural,
            body=body,
        )

    return safe_call(
        component="k8s",
        operation="create_custom_object",
        fn=_call,
        details={"group": group, "version": version, "plural": plural},
    )


def patch_custom_object_status(
    config: K8sConfig,
    *,
    group: str,
    version: str,
    plural: str,
    name: str,
    status: dict[str, Any],
    namespace: str | None = None,
) -> Result[dict[str, Any]]:
    api_result = custom_objects_api(config)
    if api_result.failed:
        return Result.fail(api_result.error)

    def _call() -> dict[str, Any]:
        return api_result.unwrap().patch_namespaced_custom_object_status(
            group=group,
            version=version,
            namespace=namespace or config.namespace,
            plural=plural,
            name=name,
            body={"status": status},
        )

    return safe_call(
        component="k8s",
        operation="patch_custom_object_status",
        fn=_call,
        details={"group": group, "version": version, "plural": plural, "name": name},
    )
