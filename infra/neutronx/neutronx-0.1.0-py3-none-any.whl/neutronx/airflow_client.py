from __future__ import annotations

from typing import Any

from .config import AirflowConfig, ApiConfig
from .http_client import get_json, post_json
from .result import Result


def _base_api_url(config: AirflowConfig) -> str:
    if not config.base_url:
        raise ValueError("Airflow base_url is required")
    return f"{config.base_url.rstrip('/')}/api/{config.api_version.strip('/')}"


def _auth(config: AirflowConfig) -> tuple[str, str] | None:
    if config.username and config.password:
        return (config.username, config.password)
    return None


def _headers(config: AirflowConfig) -> dict[str, str]:
    headers: dict[str, str] = {}
    if config.token:
        headers["Authorization"] = f"Bearer {config.token}"
    return headers


def _api_config(config: AirflowConfig) -> ApiConfig:
    return ApiConfig(
        timeout_seconds=config.timeout_seconds,
        verify_tls=config.verify_tls,
    )


def trigger_dag(
    config: AirflowConfig,
    *,
    dag_id: str,
    conf: dict[str, Any] | None = None,
    dag_run_id: str | None = None,
    logical_date: str | None = None,
) -> Result[Any]:
    payload: dict[str, Any] = {"conf": conf or {}}
    if dag_run_id:
        payload["dag_run_id"] = dag_run_id
    if logical_date:
        # Airflow v1 uses logical_date; older Airflow 2 examples may use execution_date.
        payload["logical_date"] = logical_date

    url = f"{_base_api_url(config)}/dags/{dag_id}/dagRuns"
    return post_json(
        url,
        payload=payload,
        api_config=_api_config(config),
        headers=_headers(config),
        auth=_auth(config),
    )


def get_dag_run(config: AirflowConfig, *, dag_id: str, dag_run_id: str) -> Result[Any]:
    url = f"{_base_api_url(config)}/dags/{dag_id}/dagRuns/{dag_run_id}"
    return get_json(
        url,
        api_config=_api_config(config),
        headers=_headers(config),
        auth=_auth(config),
    )


def get_dag(config: AirflowConfig, *, dag_id: str) -> Result[Any]:
    url = f"{_base_api_url(config)}/dags/{dag_id}"
    return get_json(
        url,
        api_config=_api_config(config),
        headers=_headers(config),
        auth=_auth(config),
    )
