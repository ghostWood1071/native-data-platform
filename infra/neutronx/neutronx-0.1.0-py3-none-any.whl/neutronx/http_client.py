from __future__ import annotations

from typing import Any

from .config import ApiConfig
from .retry import retry_result
from .result import Result


def request_json(
    *,
    method: str,
    url: str,
    api_config: ApiConfig | None = None,
    headers: dict[str, str] | None = None,
    params: dict[str, Any] | None = None,
    payload: dict[str, Any] | list[Any] | None = None,
    auth: tuple[str, str] | None = None,
    attempts: int = 3,
) -> Result[Any]:
    api_config = api_config or ApiConfig()

    def _call() -> Any:
        import requests

        merged_headers = dict(api_config.default_headers)
        merged_headers.update(headers or {})

        resp = requests.request(
            method=method.upper(),
            url=url,
            headers=merged_headers,
            params=params,
            json=payload,
            auth=auth,
            timeout=api_config.timeout_seconds,
            verify=api_config.verify_tls,
        )
        resp.raise_for_status()

        if resp.content:
            content_type = resp.headers.get("content-type", "")
            if "application/json" in content_type:
                return resp.json()
            return resp.text
        return None

    return retry_result(
        component="http",
        operation=f"{method.upper()} {url}",
        fn=_call,
        attempts=attempts,
        details={"url": url, "method": method.upper()},
    )


def get_json(url: str, **kwargs: Any) -> Result[Any]:
    return request_json(method="GET", url=url, **kwargs)


def post_json(url: str, payload: dict[str, Any] | list[Any] | None = None, **kwargs: Any) -> Result[Any]:
    return request_json(method="POST", url=url, payload=payload, **kwargs)
