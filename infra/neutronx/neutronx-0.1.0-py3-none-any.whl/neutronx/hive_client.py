from __future__ import annotations

from pathlib import Path
from typing import Any

from .config import HiveConfig
from .retry import safe_call
from .result import Result


def make_hive_connection(config: HiveConfig) -> Result[Any]:
    def _call() -> Any:
        if not config.host:
            raise ValueError("Hive host is required")

        from pyhive import hive

        kwargs: dict[str, Any] = {
            "host": config.host,
            "port": config.port,
            "database": config.database,
            "auth": config.auth,
        }
        if config.username:
            kwargs["username"] = config.username
        if config.kerberos_service_name:
            kwargs["kerberos_service_name"] = config.kerberos_service_name

        return hive.Connection(**kwargs)

    return safe_call(component="hive", operation="make_connection", fn=_call)


def execute_hive(
    config: HiveConfig,
    *,
    sql: str,
    fetch: bool = True,
) -> Result[list[tuple] | int]:
    conn_result = make_hive_connection(config)
    if conn_result.failed:
        return Result.fail(conn_result.error)

    def _call() -> list[tuple] | int:
        conn = conn_result.unwrap()
        try:
            cursor = conn.cursor()
            cursor.execute(sql)
            if fetch:
                return cursor.fetchall()
            return cursor.rowcount
        finally:
            conn.close()

    return safe_call(
        component="hive",
        operation="execute_hive",
        fn=_call,
        details={"fetch": fetch, "sql_preview": sql[:200]},
    )


def execute_hive_file(
    config: HiveConfig,
    *,
    file_path: str,
    params: dict[str, Any] | None = None,
    fetch: bool = True,
) -> Result[list[tuple] | int]:
    def _render() -> str:
        sql = Path(file_path).read_text(encoding="utf-8")
        return sql.format(**(params or {}))

    render_result = safe_call(
        component="hive",
        operation="render_sql_file",
        fn=_render,
        details={"file_path": file_path},
    )
    if render_result.failed:
        return Result.fail(render_result.error)

    return execute_hive(config, sql=render_result.unwrap(), fetch=fetch)
