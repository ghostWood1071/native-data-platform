from __future__ import annotations

import os
from dataclasses import asdict, dataclass, field
from typing import Any


def _env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "y"}


def _env_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None or value == "":
        return default
    return int(value)


def _redact(data: dict[str, Any]) -> dict[str, Any]:
    secret_words = ("password", "secret", "token", "access_key", "keytab", "apikey")
    out: dict[str, Any] = {}
    for k, v in data.items():
        if isinstance(v, dict):
            out[k] = _redact(v)
        elif any(word in k.lower() for word in secret_words) and v:
            out[k] = "***REDACTED***"
        else:
            out[k] = v
    return out


@dataclass(frozen=True)
class MinioConfig:
    endpoint: str | None = None
    access_key: str | None = None
    secret_key: str | None = None
    secure: bool = False
    region: str | None = None
    s3a_endpoint_protocol: str = "http"

    @classmethod
    def from_env(cls) -> "MinioConfig":
        return cls(
            endpoint=os.getenv("ONPREM_MINIO_ENDPOINT"),
            access_key=os.getenv("ONPREM_MINIO_ACCESS_KEY"),
            secret_key=os.getenv("ONPREM_MINIO_SECRET_KEY"),
            secure=_env_bool("ONPREM_MINIO_SECURE", False),
            region=os.getenv("ONPREM_MINIO_REGION"),
            s3a_endpoint_protocol=os.getenv("ONPREM_MINIO_S3A_PROTOCOL", "http"),
        )


@dataclass(frozen=True)
class AirflowConfig:
    base_url: str | None = None
    username: str | None = None
    password: str | None = None
    token: str | None = None
    api_version: str = "v1"
    timeout_seconds: int = 30
    verify_tls: bool = False

    @classmethod
    def from_env(cls) -> "AirflowConfig":
        return cls(
            base_url=os.getenv("ONPREM_AIRFLOW_BASE_URL"),
            username=os.getenv("ONPREM_AIRFLOW_USERNAME"),
            password=os.getenv("ONPREM_AIRFLOW_PASSWORD"),
            token=os.getenv("ONPREM_AIRFLOW_TOKEN"),
            api_version=os.getenv("ONPREM_AIRFLOW_API_VERSION", "v1"),
            timeout_seconds=_env_int("ONPREM_AIRFLOW_TIMEOUT_SECONDS", 30),
            verify_tls=_env_bool("ONPREM_AIRFLOW_VERIFY_TLS", False),
        )


@dataclass(frozen=True)
class KafkaConfig:
    bootstrap_servers: str | None = None
    security_protocol: str | None = None
    sasl_mechanism: str | None = None
    sasl_username: str | None = None
    sasl_password: str | None = None
    extra_config: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_env(cls) -> "KafkaConfig":
        return cls(
            bootstrap_servers=os.getenv("ONPREM_KAFKA_BOOTSTRAP_SERVERS"),
            security_protocol=os.getenv("ONPREM_KAFKA_SECURITY_PROTOCOL"),
            sasl_mechanism=os.getenv("ONPREM_KAFKA_SASL_MECHANISM"),
            sasl_username=os.getenv("ONPREM_KAFKA_SASL_USERNAME"),
            sasl_password=os.getenv("ONPREM_KAFKA_SASL_PASSWORD"),
        )

    def to_confluent_config(self) -> dict[str, Any]:
        conf: dict[str, Any] = {"bootstrap.servers": self.bootstrap_servers}
        if self.security_protocol:
            conf["security.protocol"] = self.security_protocol
        if self.sasl_mechanism:
            conf["sasl.mechanism"] = self.sasl_mechanism
        if self.sasl_username:
            conf["sasl.username"] = self.sasl_username
        if self.sasl_password:
            conf["sasl.password"] = self.sasl_password
        conf.update(self.extra_config)
        return {k: v for k, v in conf.items() if v is not None}


@dataclass(frozen=True)
class MongoConfig:
    uri: str | None = None
    database: str | None = None
    timeout_ms: int = 5000

    @classmethod
    def from_env(cls) -> "MongoConfig":
        return cls(
            uri=os.getenv("ONPREM_MONGO_URI"),
            database=os.getenv("ONPREM_MONGO_DATABASE"),
            timeout_ms=_env_int("ONPREM_MONGO_TIMEOUT_MS", 5000),
        )


@dataclass(frozen=True)
class K8sConfig:
    namespace: str = "default"
    in_cluster: bool = True
    kubeconfig_path: str | None = None

    @classmethod
    def from_env(cls) -> "K8sConfig":
        return cls(
            namespace=os.getenv("ONPREM_K8S_NAMESPACE", "default"),
            in_cluster=_env_bool("ONPREM_K8S_IN_CLUSTER", True),
            kubeconfig_path=os.getenv("ONPREM_K8S_KUBECONFIG_PATH"),
        )


@dataclass(frozen=True)
class ApiConfig:
    timeout_seconds: int = 30
    verify_tls: bool = False
    default_headers: dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_env(cls) -> "ApiConfig":
        return cls(
            timeout_seconds=_env_int("ONPREM_API_TIMEOUT_SECONDS", 30),
            verify_tls=_env_bool("ONPREM_API_VERIFY_TLS", False),
        )


@dataclass(frozen=True)
class HiveConfig:
    host: str | None = None
    port: int = 10000
    username: str | None = None
    database: str = "default"
    auth: str = "NONE"
    kerberos_service_name: str | None = None

    @classmethod
    def from_env(cls) -> "HiveConfig":
        return cls(
            host=os.getenv("ONPREM_HIVE_HOST"),
            port=_env_int("ONPREM_HIVE_PORT", 10000),
            username=os.getenv("ONPREM_HIVE_USERNAME"),
            database=os.getenv("ONPREM_HIVE_DATABASE", "default"),
            auth=os.getenv("ONPREM_HIVE_AUTH", "NONE"),
            kerberos_service_name=os.getenv("ONPREM_HIVE_KERBEROS_SERVICE_NAME"),
        )


@dataclass(frozen=True)
class OpenMetadataConfig:
    base_url: str | None = None
    token: str | None = None
    timeout_seconds: int = 30
    verify_tls: bool = False

    @classmethod
    def from_env(cls) -> "OpenMetadataConfig":
        return cls(
            base_url=os.getenv("ONPREM_OPENMETADATA_BASE_URL"),
            token=os.getenv("ONPREM_OPENMETADATA_TOKEN"),
            timeout_seconds=_env_int("ONPREM_OPENMETADATA_TIMEOUT_SECONDS", 30),
            verify_tls=_env_bool("ONPREM_OPENMETADATA_VERIFY_TLS", False),
        )


@dataclass(frozen=True)
class OpenLineageConfig:
    endpoint: str | None = None
    namespace: str = "onprem-data-platform"
    timeout_seconds: int = 30
    verify_tls: bool = False

    @classmethod
    def from_env(cls) -> "OpenLineageConfig":
        return cls(
            endpoint=os.getenv("ONPREM_OPENLINEAGE_ENDPOINT"),
            namespace=os.getenv("ONPREM_OPENLINEAGE_NAMESPACE", "onprem-data-platform"),
            timeout_seconds=_env_int("ONPREM_OPENLINEAGE_TIMEOUT_SECONDS", 30),
            verify_tls=_env_bool("ONPREM_OPENLINEAGE_VERIFY_TLS", False),
        )


@dataclass(frozen=True)
class PlatformConfig:
    minio: MinioConfig = field(default_factory=MinioConfig)
    airflow: AirflowConfig = field(default_factory=AirflowConfig)
    kafka: KafkaConfig = field(default_factory=KafkaConfig)
    mongo: MongoConfig = field(default_factory=MongoConfig)
    k8s: K8sConfig = field(default_factory=K8sConfig)
    api: ApiConfig = field(default_factory=ApiConfig)
    hive: HiveConfig = field(default_factory=HiveConfig)
    openmetadata: OpenMetadataConfig = field(default_factory=OpenMetadataConfig)
    openlineage: OpenLineageConfig = field(default_factory=OpenLineageConfig)

    @classmethod
    def from_env(cls) -> "PlatformConfig":
        return cls(
            minio=MinioConfig.from_env(),
            airflow=AirflowConfig.from_env(),
            kafka=KafkaConfig.from_env(),
            mongo=MongoConfig.from_env(),
            k8s=K8sConfig.from_env(),
            api=ApiConfig.from_env(),
            hive=HiveConfig.from_env(),
            openmetadata=OpenMetadataConfig.from_env(),
            openlineage=OpenLineageConfig.from_env(),
        )

    def redacted_dict(self) -> dict[str, Any]:
        return _redact(asdict(self))
