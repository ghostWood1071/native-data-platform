from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Generic, TypeVar

from .errors import PlatformException, PlatformError

T = TypeVar("T")
U = TypeVar("U")


@dataclass(frozen=True)
class Result(Generic[T]):
    value: T | None = None
    error: PlatformError | None = None

    @property
    def ok(self) -> bool:
        return self.error is None

    @property
    def failed(self) -> bool:
        return self.error is not None

    @classmethod
    def success(cls, value: T) -> "Result[T]":
        return cls(value=value)

    @classmethod
    def fail(cls, error: PlatformError) -> "Result[T]":
        return cls(error=error)

    def unwrap(self) -> T:
        if self.error is not None:
            raise PlatformException(self.error)
        return self.value  # type: ignore[return-value]

    def unwrap_or(self, default: T) -> T:
        if self.error is not None:
            return default
        return self.value  # type: ignore[return-value]

    def map(self, fn: Callable[[T], U]) -> "Result[U]":
        if self.error is not None:
            return Result.fail(self.error)
        try:
            return Result.success(fn(self.value))  # type: ignore[arg-type]
        except Exception as exc:
            return Result.fail(
                PlatformError.from_exception(
                    component="result",
                    operation="map",
                    exc=exc,
                )
            )
